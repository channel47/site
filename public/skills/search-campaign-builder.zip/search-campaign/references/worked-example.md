# Worked Example: Building a Campaign from a Landing Page

This reference shows the complete process of analyzing a real landing page and building a Google Search campaign.

---

## Example: Notion (Project Management SaaS)

### Landing Page Analysis

**URL:** notion.com

**What I Extracted:**

| Element | Found | Use In Campaign |
|---------|-------|-----------------|
| H1 Headline | "One workspace. Zero busywork." | Headline 1 |
| Subheadline | "AI agents that work for you" | Headline variation |
| Key Stat | "62% of Fortune 100 companies" | Social proof headline |
| Key Stat | "100M+ users" | Social proof description |
| Case Study | "Toyota: 3x faster timelines" | Proof point |
| CTA | "Get Notion free" | CTA headline |
| Audience | Teams, startups, enterprise | Keyword modifiers |
| Problem | "workflow fragmentation," "busywork" | Problem-aware keywords |
| Solution | "all-in-one workspace," "AI agents" | Solution keywords |

**5-Second Test Result:** "It's a workspace app with AI that reduces busywork for teams."

**Red Flags:** None major. Clear value prop, strong social proof, specific benefits.

---

### Campaign Structure

**Campaign:** Notion - Search (Non-Brand)

#### Ad Group 1: High-Intent Solution Seekers

**Intent:** Transactional / Commercial Investigation

These are people actively looking for a solution. Highest conversion potential.

**Keywords:**
- [project management software] phrase
- [team workspace app] phrase
- [all in one workspace] phrase
- [collaboration software for teams] phrase
- [work management platform] phrase
- [notion pricing] exact
- [buy notion] exact

**Why these grouped:** All share intent "I want a tool like this" — same ad works for all.

**Ad Copy:**

Headlines (15):
1. All-in-One Team Workspace (30 chars) — Value prop from page
2. Notion - One Workspace, Zero Busywork (30 chars) — Direct lift from H1
3. 62% of Fortune 100 Use Notion (30 chars) — Social proof
4. AI That Handles Your Busywork (30 chars) — Feature as benefit
5. Get Notion Free - No Card (26 chars) — Low-friction CTA
6. Replace 5 Tools With One (25 chars) — Consolidation benefit
7. 100M+ Users Trust Notion (25 chars) — Scale social proof
8. Project Management Made Easy (30 chars) — Category + benefit
9. Team Collaboration Software (28 chars) — Category match
10. Toyota Cut Timelines by 3X (27 chars) — Case study proof
11. Docs, Projects, AI - One App (29 chars) — Feature summary
12. Try Notion for Teams Free (26 chars) — Audience + CTA
13. Stop Switching Between Tools (29 chars) — Problem agitation
14. Workspace That Works for You (29 chars) — Benefit framing
15. Start Free, Scale When Ready (29 chars) — Low risk + growth

Descriptions (4):
1. "One workspace for docs, projects, and AI automation. Join 100M+ users and 62% of Fortune 100. Get started free." (108 chars) — Benefit-led
2. "Stop juggling 5 different tools. Notion brings docs, projects, and team knowledge into one AI-powered workspace. Try free." (122 chars) — Problem-led
3. "AI agents handle your busywork while you focus on real work. See why Toyota, Nike, and Spotify trust Notion. Free to start." (123 chars) — AI + social proof
4. "Docs. Projects. Knowledge base. All searchable by AI. One workspace that makes teams 3X more efficient. No credit card." (119 chars) — Feature + outcome

**Pinning:**
- Position 1: "All-in-One Team Workspace" or "Notion - One Workspace, Zero Busywork"
- Position 2: "62% of Fortune 100 Use Notion" (social proof always shows)

---

#### Ad Group 2: Problem-Aware Searchers

**Intent:** Commercial Investigation

These people know they have a problem but aren't sure what solution they need yet.

**Keywords:**
- [team productivity tools] phrase
- [reduce busywork software] phrase
- [too many work apps] phrase
- [scattered work documents] phrase
- [team knowledge management] phrase
- [document collaboration tool] phrase

**Why these grouped:** All express the PROBLEM (fragmentation, busywork, scattered info) — need problem-agitation ads.

**Ad Copy:**

Headlines (15):
1. Tired of Tool Overload? (23 chars)
2. One Workspace Replaces Five (27 chars)
3. Stop the App Switching (22 chars)
4. Your Team's Brain, Organized (29 chars)
5. End the Busywork - Use AI (25 chars)
6. Scattered Docs? One Solution (29 chars)
7. Notion - Team Productivity (27 chars)
8. Work Faster, Switch Less (24 chars)
9. AI Handles the Grunt Work (26 chars)
10. Knowledge in One Place (22 chars)
11. 100M+ Teams Made the Switch (28 chars)
12. Get Organized - Get Notion (27 chars)
13. From Chaos to Clarity (21 chars)
14. Free Workspace for Teams (25 chars)
15. See Why Teams Switch to Us (27 chars)

Descriptions (4):
1. "Juggling Slack, Docs, Asana, and more? Notion combines everything into one AI-powered workspace. 100M+ users already switched." (126 chars)
2. "When info lives in 5 different apps, work slows down. Notion brings it all together. See why Fortune 100 companies trust us." (124 chars)
3. "Your team's documents, projects, and knowledge — searchable, connected, and powered by AI. Start free, upgrade when ready." (121 chars)
4. "Scattered tools = scattered teams. One workspace changes everything. Join Toyota, Spotify, and Nike. No credit card required." (124 chars)

---

#### Ad Group 3: Competitor Alternative Seekers

**Intent:** Commercial Investigation (Comparison)

People searching for alternatives to competitors. They're shopping.

**Keywords:**
- [asana alternative] phrase
- [monday alternative] phrase
- [confluence alternative] phrase
- [trello alternative] phrase
- [notion vs asana] exact
- [notion vs monday] exact
- [better than monday] phrase

**Why these grouped:** All explicitly comparing/seeking alternatives — need differentiation messaging.

**Ad Copy:**

Headlines (15):
1. The Asana Alternative (21 chars)
2. Switch From Monday.com (23 chars)
3. More Than Just Tasks (20 chars)
4. Beyond Project Management (25 chars)
5. Notion vs. The Rest (19 chars)
6. Why Teams Leave Asana (21 chars)
7. Confluence, But Better (23 chars)
8. All-in-One, Not Add-Ons (23 chars)
9. Compare Notion Free (19 chars)
10. Docs + Projects + AI (20 chars)
11. No Per-Seat Surprises (21 chars)
12. Teams Switch for a Reason (26 chars)
13. See the Difference Free (24 chars)
14. One Tool, Not a Stack (21 chars)
15. Try Before You Switch (22 chars)

Descriptions (4):
1. "Why pay for Asana, Confluence, AND Trello? Notion combines them all. Docs, projects, wiki — one workspace. Compare free." (120 chars)
2. "Tired of Monday.com's complexity? Notion is simpler but more powerful. AI automation included. No credit card to start." (118 chars)
3. "Teams switch from Asana when they want more than task lists. Notion adds docs, knowledge base, and AI. See why." (110 chars)
4. "Most project tools only do one thing. Notion does it all — without the per-seat pricing surprises. Compare features free." (121 chars)

---

#### Ad Group 4: Brand Terms

**Intent:** Navigational

People searching for Notion specifically. High intent, protect the brand.

**Keywords:**
- [notion] exact
- [notion app] exact
- [notion workspace] exact
- [notion login] exact
- [notion for teams] exact
- [notion ai] exact

**Note:** These should be in a SEPARATE CAMPAIGN with different budget. Brand terms have different economics — lower CPCs, higher conversion, but you'd often get this traffic organically.

**Why run brand campaigns:**
- Protect against competitor bidding on your brand
- Control the message
- Ensure top position

---

### Negative Keywords

**Campaign-Level Negatives:**
```
free alternative
open source
jobs
careers
hiring
salary
intern
tutorial
how to use
course
training
certification
reddit
quora
forum
template
download
review
reviews
reddit
student
education discount
vs notion (for non-competitor ad groups)
notion template
```

**Ad Group-Specific:**

For "Competitor Alternative" ad group, add negative:
- [competitor] login
- [competitor] pricing (unless you're competitive)
- [competitor] support

For "Problem-Aware" ad group:
- diy
- free
- open source

---

### Extensions

**Sitelinks:**
1. Pricing & Plans | See which plan fits your team | /pricing
2. For Enterprise | Security, SSO, custom onboarding | /enterprise
3. AI Features | Automate busywork with Notion AI | /product/ai
4. Templates | 1000+ ready-made templates | /templates
5. Customer Stories | How teams use Notion | /customers
6. Product Overview | See everything Notion does | /product

**Callouts:**
- Free Forever Plan
- AI-Powered Search
- No Credit Card Required
- 24/7 Support
- SSO & Advanced Security
- Mobile & Desktop Apps

**Structured Snippets:**
- Features: Docs, Projects, Wiki, AI Automation, Database, Calendar
- Types: Team Workspace, Knowledge Base, Project Management, Documentation

---

### Bidding Recommendation

**For New Campaign (No Historical Data):**

Start with **Maximize Conversions** without a target.

Why: You don't have data yet. Let Google learn what converts, then set targets.

After 30+ conversions/month → Switch to **Target CPA** based on your actual average CPA.

**Budget Allocation:**
- 50% → High-Intent Solution (Ad Group 1) — highest conversion potential
- 25% → Competitor Alternatives (Ad Group 3) — shopping intent
- 15% → Problem-Aware (Ad Group 2) — earlier funnel
- 10% → Brand (separate campaign) — protection

---

### What This Campaign Gets Right

1. **Intent Segmentation:** Each ad group has ONE intent. The ads match.

2. **Message Match:** Headlines use exact language from the landing page ("One workspace, zero busywork," "62% of Fortune 100").

3. **Specificity Over Generics:** "100M+ users" and "62% of Fortune 100" — not "Trusted by many companies."

4. **Problem-Solution Framing:** Problem-aware ad group agitates the pain before offering the solution.

5. **Defense:** Comprehensive negative keywords prevent waste on free-seekers, job-hunters, and students.

6. **Proof at Every Level:** Social proof in headlines, descriptions, and extensions.

7. **Low-Friction CTAs:** "Get Notion Free," "No Credit Card" — reduces hesitation.

---

## Before/After Comparison

### Claude's Default Output (No Skill)

```
Campaign: Notion Productivity Software

Ad Group 1: General Keywords
- notion app
- notion software
- productivity software
- workspace app
- note taking app

Headlines:
- Notion - All-in-One Workspace
- Boost Your Productivity Today
- AI-Powered Productivity Tool
- Try Notion Free Today

Descriptions:
- Notion is the all-in-one workspace that combines notes, docs,
  and project management. Join 100M+ users. Get started free.
```

**What's Wrong:**
- Mixed intent (brand + category + feature keywords in one group)
- Generic headlines ("Boost Your Productivity Today" — could be any tool)
- No match types specified
- No negative keywords
- No proof points in headlines
- Missing extensions
- No structure rationale

### With This Skill

```
Campaign: Notion - Search (Non-Brand)

Ad Group 1: High-Intent Solution Seekers
- [project management software] phrase
- [team workspace app] phrase
- [all in one workspace] phrase

Headlines:
- All-in-One Team Workspace
- 62% of Fortune 100 Use Notion
- Notion - One Workspace, Zero Busywork
- Toyota Cut Timelines by 3X
...

Descriptions:
- One workspace for docs, projects, and AI automation.
  Join 100M+ users and 62% of Fortune 100. Get started free.
...

Negative Keywords: free alternative, jobs, how to use, reddit...
Extensions: [full list]
```

**What's Right:**
- Single intent per ad group
- Headlines lift language from landing page
- Specific proof points (not "trusted by many")
- Match types specified
- Comprehensive negatives
- Full extension suite
- Clear structure rationale

---

## Using This Example

When you build campaigns:

1. **Start with the landing page** — What does it actually say? Extract, don't invent.

2. **Group by intent** — Would these searchers all expect the same ad?

3. **Lift language** — Headlines should sound like the landing page.

4. **Prove everything** — Stats and case studies > generic claims.

5. **Defend the budget** — Negatives are as important as keywords.

6. **Think in layers** — Different intent levels get different messaging.

The Notion example shows how a single landing page generates 4+ distinct ad groups, each with tailored messaging for its specific intent level.
