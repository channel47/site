# Negative Keyword Reference

Comprehensive negative keyword lists to prevent budget waste.

---

## Universal Negatives (Add to Every Campaign)

These queries almost never convert for paid products/services:

### Job Seekers

```
jobs
careers
hiring
salary
salaries
intern
internship
employment
work for
working at
glassdoor
indeed
linkedin
resume
interview
```

### Free Seekers

```
free
gratis
freeware
open source
torrent
crack
cracked
pirated
download free
free download
```

### Students / Researchers

```
tutorial
how to
what is
definition
define
meaning
example
examples
sample
samples
course
courses
training
certification
certified
exam
quiz
test
academic
research paper
thesis
dissertation
pdf
ppt
powerpoint
```

### Forum / Community

```
reddit
quora
forum
forums
community
discussion
blog
blogs
wiki
wikipedia
```

### DIY / Self-Service

```
diy
do it yourself
homemade
make your own
build your own
template
templates
```

### Reviews / Research (Unless Running Review Content)

```
review
reviews
comparison
compare
versus
vs
ratings
rating
complaints
scam
legit
```

---

## Industry-Specific Negatives

### SaaS / Software

```
open source
free alternative
github
self hosted
self-hosted
code
coding
developer
api documentation
sdk
```

### E-commerce

```
used
second hand
secondhand
pre-owned
refurbished
cheap
cheapest
bargain
wholesale
bulk
coupon
coupon code
discount code
promo code
clearance
outlet
```

### B2B Services

```
salary
jobs
careers
freelance
contractor
diy
template
```

### Local Services

```
jobs
hiring
near me (if not serving that area)
[wrong city names]
[wrong state names]
how to
diy
```

### Professional Services (Law, Accounting, etc.)

```
pro bono
free consultation
free advice
jobs
careers
salary
school
degree
certification
```

---

## Match Type Strategy for Negatives

### Negative Exact Match

Use when you want to block ONLY that exact query:

```
-[notion jobs]
-[notion careers]
-[notion free download]
```

**Best for:** Precise exclusions, specific competitor terms you don't want.

### Negative Phrase Match

Use when you want to block any query containing that phrase:

```
-"free download"
-"how to"
-"jobs at"
```

**Best for:** Most negative keywords — blocks variations automatically.

### Negative Broad Match

Use when you want to block any query containing those words in any order:

```
-free template
-salary range
-job openings
```

**Best for:** Catching variations you haven't thought of.

**Warning:** Broad match negatives can be aggressive. Test carefully.

---

## Building Your Negative List: Process

### Week 1: Start with Universals

Add the universal negative lists above before launching.

### Week 2+: Review Search Terms Report

1. Go to Keywords > Search Terms
2. Sort by Impressions or Cost
3. Look for queries that:
   - Have clicks but no conversions
   - Are clearly wrong intent
   - Mention competitors you don't want
   - Are informational when you want transactional

4. Add as negatives

### Monthly: Audit and Expand

- Review which negatives are blocking significant volume
- Check for patterns in wasted spend
- Update based on new irrelevant queries

---

## Negative Keyword Lists (Account Level)

Create shared negative keyword lists for efficiency:

### List: Job Seekers
All job-related terms — apply to all campaigns.

### List: Free Seekers
All free/piracy terms — apply to paid product campaigns.

### List: Informational
Tutorial, how-to, research terms — apply to bottom-funnel campaigns.

### List: Geographic Exclusions
Cities/states you don't serve — apply to local campaigns.

### List: Brand Negatives
Competitors you don't want to bid against — apply selectively.

---

## Warning: Over-Negating

Don't add negatives blindly. Some "informational" queries convert:

| Query Type | Might Actually Convert If... |
|------------|------------------------------|
| "how to [solve problem]" | Your product IS the solution |
| "[category] comparison" | You have comparison content |
| "best [category]" | You're a top option |
| "[competitor] alternative" | You explicitly target this |

**Rule:** Only negative keywords that CONSISTENTLY waste budget without conversions.

---

## Competitor-Specific Negatives

### When to Add Competitors as Negatives

Add competitors as negatives EXCEPT in your "Competitor Alternative" ad group:

```
# Add to all ad groups EXCEPT competitor targeting:
-[competitor] login
-[competitor] support
-[competitor] pricing
-[competitor] careers
```

### When NOT to Negative Competitors

If you're targeting "[competitor] alternative" searches, don't negative the competitor name — you need it to trigger.

But DO negative:
- [competitor] login
- [competitor] support
- [competitor] help
- [competitor] contact

These are existing customers, not prospects.

---

## Common Negative Keyword Mistakes

### 1. Adding Negatives Too Broadly

**Mistake:** Adding "free" as a broad negative.
**Problem:** Blocks "free trial" and "free shipping" — which you might offer.
**Fix:** Use phrase match: -"free download", -"free alternative"

### 2. Forgetting Match Types

**Mistake:** Adding negatives without specifying match type.
**Problem:** Default is broad — might block more than intended.
**Fix:** Always specify: -[exact], -"phrase", or -broad

### 3. Never Reviewing the List

**Mistake:** Set and forget.
**Problem:** Search landscape changes, new irrelevant queries appear.
**Fix:** Review monthly, update quarterly.

### 4. Negativing Converting Terms

**Mistake:** Adding "cheap" as negative because it seems low-quality.
**Problem:** Some "cheap" searchers convert — they just want affordable.
**Fix:** Check conversion data before adding negatives.

---

## Quick Reference: Copy-Paste Lists

### Universal Starter List (Phrase Match)

```
"free download"
"jobs at"
"careers at"
"how to"
"what is"
"tutorial"
"template"
"example"
"reddit"
"quora"
"forum"
"wiki"
"pdf"
"diy"
"do it yourself"
"salary"
"hiring"
"intern"
"course"
"training"
"certification"
```

### E-commerce Starter List (Phrase Match)

```
"used"
"second hand"
"refurbished"
"coupon code"
"discount code"
"wholesale"
"bulk order"
"cheap"
"cheapest"
"clearance"
```

### SaaS Starter List (Phrase Match)

```
"open source"
"free alternative"
"github"
"self hosted"
"api documentation"
"source code"
"login"
"sign in"
"customer support"
"help center"
```

### Local Services Starter List (Phrase Match)

```
"jobs"
"careers"
"hiring"
"salary"
"near me" (if not relevant)
"diy"
"how to"
```
