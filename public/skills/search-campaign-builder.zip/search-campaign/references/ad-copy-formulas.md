# Ad Copy Formulas & Patterns

Reference material for writing Google Search ads that convert.

---

## Headline Formulas (30 Character Limit)

### Value Proposition Headlines

| Formula | Example | When to Use |
|---------|---------|-------------|
| [Benefit] - [Brand] | "Save 3 Hours Daily - Notion" | Position 1, anchor message |
| [Category] + [Differentiator] | "CRM That Sells Itself" | Competitive categories |
| [Result] in [Timeframe] | "Fluent Spanish in 90 Days" | Outcome-focused products |
| [Number] [Thing] [Benefit] | "10K+ Teams Trust Us" | Social proof |
| [Adjective] [Category] | "Effortless Scheduling" | Benefit-modified category |

### Problem-Agitation Headlines

| Formula | Example | When to Use |
|---------|---------|-------------|
| [Pain Point]? | "Missed Deadlines?" | Problem-aware searches |
| Stop [Bad Thing] | "Stop Losing Leads" | Urgency |
| Tired of [Problem]? | "Tired of Spreadsheets?" | Frustration searches |
| [Problem] Solved | "Scheduling Chaos Solved" | Solution positioning |
| No More [Pain] | "No More Manual Reports" | Elimination benefit |

### CTA Headlines

| Formula | Example | When to Use |
|---------|---------|-------------|
| Get [Thing] Free | "Get Your Free Demo" | Lead gen |
| Try [Brand] Free | "Try Notion Free Today" | Free trial products |
| [Action] + [Timeframe] | "Start in 5 Minutes" | Low-friction offers |
| See [Proof Point] | "See Why Teams Switch" | Social proof CTA |
| Compare [Thing] Free | "Compare Plans Free" | Consideration stage |

### Proof Point Headlines

| Formula | Example | When to Use |
|---------|---------|-------------|
| [Number]+ [Thing] Trust Us | "50,000+ Teams Trust Us" | Scale social proof |
| [Percent] of [Impressive Group] | "62% of Fortune 100" | Authority proof |
| [Result] for [Customer] | "3X Faster for Toyota" | Case study proof |
| Award-Winning [Category] | "Award-Winning CRM" | Credential proof |
| [Number] [Metric] [Improvement] | "47% More Conversions" | Results proof |

### Competitive Headlines

| Formula | Example | When to Use |
|---------|---------|-------------|
| The [Competitor] Alternative | "The Salesforce Alternative" | Competitor keyword targeting |
| Beyond [Category] | "Beyond Project Management" | Differentiation |
| [Thing], Not [Limitation] | "Power, Not Complexity" | Positioning against weakness |
| Why Teams Leave [Competitor] | "Why Teams Leave Monday" | Aggressive positioning |
| More Than Just [Feature] | "More Than Just Tasks" | Expansion messaging |

---

## Description Formulas (90 Character Limit)

### Benefit-Led Description

```
[Primary benefit]. [Supporting benefit]. [CTA with low friction].
```

**Example:** "One workspace for docs, projects, and AI automation. Join 100M+ users. Get started free."

### Problem-Led Description

```
[Pain point acknowledgment]. [Solution]. [CTA].
```

**Example:** "Juggling 5 different tools? Notion brings everything together. Try free, no credit card."

### Proof-Led Description

```
[Social proof / credential]. [Key benefit]. [CTA].
```

**Example:** "Trusted by 62% of Fortune 100 companies. AI-powered workspace for modern teams. Compare free."

### Feature-Led Description

```
[Key features]. [Differentiator or outcome]. [CTA].
```

**Example:** "Docs, projects, wikis, and AI search in one app. Replace your entire tool stack. Start free."

### Urgency-Led Description

```
[Time-limited element]. [Key benefit]. [CTA].
```

**Example:** "Limited spots for Q1 onboarding. Dedicated setup support for enterprise teams. Book now."

---

## Psychological Triggers

### Loss Aversion (2x more powerful than gains)

| Bad | Better |
|-----|--------|
| "Get more leads" | "Stop losing leads" |
| "Increase productivity" | "Eliminate wasted hours" |
| "Improve efficiency" | "Stop the bottlenecks" |

### Social Proof (specific numbers)

| Bad | Better |
|-----|--------|
| "Trusted by many" | "Trusted by 10,000+ teams" |
| "Popular with businesses" | "Used by 62% of Fortune 100" |
| "Great reviews" | "4.9/5 from 2,847 reviews" |

### Authority (credentials over claims)

| Bad | Better |
|-----|--------|
| "Industry leader" | "G2 Leader 5 Years Running" |
| "Trusted brand" | "Trusted by Nike, Airbnb, Toyota" |
| "Expert team" | "Built by ex-Google engineers" |

### Scarcity (genuine limits only)

| Bad | Better |
|-----|--------|
| "Limited time offer" | "Only 12 spots left for March" |
| "Act now" | "Enrollment closes Friday" |
| "Don't miss out" | "Last cohort sold out in 3 days" |

### Specificity (exact > approximate)

| Bad | Better |
|-----|--------|
| "Save time" | "Save 3.5 hours per week" |
| "Increase revenue" | "47% higher close rate" |
| "Fast results" | "See results in 14 days" |

---

## Character Count Reference

| Element | Limit | Best Practice |
|---------|-------|---------------|
| Headline 1-15 | 30 chars | Use 25-30 chars (visible on all devices) |
| Description 1-4 | 90 chars | Use 80-90 chars (maximize real estate) |
| Display Path | 15 chars each | Use for keywords (e.g., /project-management) |

### Quick Character Checks

Common words that eat character budget:

| Word | Characters | Alternative |
|------|------------|-------------|
| "management" | 10 | - |
| "professional" | 12 | "pro" (3) |
| "immediately" | 11 | "now" (3) |
| "comprehensive" | 13 | "full" (4), "complete" (8) |
| "automatically" | 13 | "auto" (4) |

---

## Anti-Patterns: What to Avoid

### Generic Phrases That Kill CTR

| Never Use | Why It Fails |
|-----------|--------------|
| "Looking for...?" | Wastes 12+ characters, states the obvious |
| "We offer..." | Company-focused, not customer-focused |
| "Best [category]" | Unsubstantiated, everyone claims this |
| "Quality service" | Meaningless without proof |
| "Click here" | Weak, non-specific CTA |
| "Learn more" | Passive, low commitment |
| "Contact us today" | Generic, no benefit |

### Feature Lists Without Benefits

| Feature-Only (Bad) | Benefit-Focused (Better) |
|--------------------|--------------------------|
| "Cloud-based software" | "Access from anywhere" |
| "24/7 support" | "Help when you need it" |
| "Advanced analytics" | "Know what's working" |
| "API integration" | "Connects to your stack" |
| "Mobile app included" | "Manage from your phone" |

### Vague Claims Without Proof

| Vague (Bad) | Specific (Better) |
|-------------|-------------------|
| "Trusted by thousands" | "47,293 teams and growing" |
| "Fast delivery" | "Ships in 2 business days" |
| "Great ROI" | "342% average ROI" |
| "Easy to use" | "Set up in 5 minutes" |
| "Affordable" | "From $9/month" |

---

## Match Types & Copy Relationship

### Exact Match → Specific Copy

When targeting [exact match], your ad copy can be highly specific to that exact query.

**Keyword:** [project management software pricing]
**Headline:** "Project Management Pricing" — Direct keyword match acceptable.

### Phrase Match → Intent-Matched Copy

Phrase match triggers for related queries, so copy should match the INTENT, not just the keyword.

**Keyword:** "project management software"
**Triggers:** "best project management software for startups," "project management software comparison"
**Headline:** "Project Management for Teams" — Covers the intent range.

### Broad Match → Benefit-Focused Copy

Broad match triggers for semantically related queries. Copy should focus on benefits that resonate across variations.

**Keyword:** project management
**Triggers:** "how to organize team projects," "tools for managing work," "team productivity apps"
**Headline:** "Organize Projects Effortlessly" — Benefit works for all variations.

---

## RSA Best Practices

### Quantity Guidelines

| Element | Minimum | Ideal | Maximum |
|---------|---------|-------|---------|
| Headlines | 8 | 12-15 | 15 |
| Descriptions | 3 | 4 | 4 |

### Diversity Guidelines

Your 15 headlines should include:

- 3 value proposition variations
- 3 proof point variations
- 3 problem/solution variations
- 3 CTA variations
- 3 keyword-rich variations

### Pinning Strategy

| Pin Position | What to Pin | Why |
|--------------|-------------|-----|
| Position 1 | Best value prop OR brand | First thing seen |
| Position 2 | Best proof point | Credibility immediately |
| Position 3 | Usually don't pin | Let Google test |

**Warning:** Over-pinning reduces combinations. Pinning all 3 positions cuts testable variations by 75%+.

### What NOT to Do

- Don't repeat the same phrase across headlines
- Don't pin single headlines to all positions
- Don't use all 30 characters for every headline (variation is good)
- Don't write headlines that only make sense together (they'll be shuffled)

---

## Industry-Specific Patterns

### SaaS / Software

**Winning patterns:**
- Free trial emphasis ("Start Free, Upgrade Later")
- Integration mentions ("Works With Your Stack")
- Time-to-value ("Set Up in Minutes")
- Team focus ("Built for Teams")

**Avoid:**
- Technical jargon without benefits
- Feature lists without outcomes

### E-commerce

**Winning patterns:**
- Shipping ("Free Shipping Over $50")
- Returns ("Easy 30-Day Returns")
- Selection ("1000+ Products In Stock")
- Price ("From $29")

**Avoid:**
- Generic quality claims
- Missing key differentiators (shipping, returns)

### Local Services

**Winning patterns:**
- Location ("Serving [City] Since 2010")
- Response time ("Same-Day Service")
- Credentials ("Licensed & Insured")
- Reviews ("4.9★ 500+ Reviews")

**Avoid:**
- Forgetting location signals
- Generic service descriptions

### B2B / Enterprise

**Winning patterns:**
- Enterprise proof ("Trusted by Fortune 500")
- Security ("SOC 2 Compliant")
- Scale ("For Teams of 50-10,000")
- ROI ("Average 340% ROI")

**Avoid:**
- Consumer-focused messaging
- Missing enterprise requirements (security, compliance)

### Lead Generation

**Winning patterns:**
- Low commitment ("Free Quote in 2 Minutes")
- Qualification ("For Businesses Over $1M")
- Urgency ("Limited Q1 Availability")
- Proof ("500+ Clients Served")

**Avoid:**
- High-commitment CTAs ("Call Us Now")
- Missing value proposition before ask
