# Variation Strategies — Deep Dive

## Why Variations Work

Ad fatigue is the #1 killer of winning creatives. When a user sees the same ad 3+ times, CTR drops, CPM rises, and ROAS craters. But the *insight* behind the ad — the offer, the angle, the hook — might still have runway.

Variations extend the life of a winner by giving the algorithm fresh creative to serve while keeping the proven strategic core intact.

## The Divergence Framework

### Subtle — Surface Refresh

**Philosophy:** Same ad, different skin. The viewer processes it as "new" at the subconscious level even though nothing strategic changed.

**What changes:**
- Background color shifts (e.g., warm white → cool white → cream)
- Gradient direction or intensity
- Shadow depth or direction
- Color temperature (cooler or warmer)
- Texture overlays (subtle grain, noise, paper)
- Filter-level adjustments (slight desaturation, contrast bump)
- Border or frame variations
- Minor spacing adjustments

**What stays locked:**
- Layout and composition
- All copy (headline, body, CTA)
- Hero element (product shot, face, illustration)
- Brand marks and logo
- Visual hierarchy
- Typography choices

**When to use:**
- The ad is crushing it and you don't want to risk changing the formula
- You need 3–6 variants fast for algorithmic diversity
- Platform is penalizing for creative repetition but the ad still converts
- Early in a campaign when you want to give the algorithm options

**Example prompts for subtle:**
- "Shift the background from pure white to a warm cream tone. Everything else stays identical."
- "Add a subtle paper texture overlay to the background. Preserve all text, product placement, and colors."
- "Change the gradient from left-to-right to top-to-bottom. Same colors, same composition."

---

### Moderate — Structural Remix

**Philosophy:** The same winning formula wearing different clothes. A viewer would say "that's a similar ad" but not "that's the same ad."

**What changes:**
- Background scene or environment
- Color palette (staying within brand range)
- Layout rearrangement (e.g., product left → product right)
- Typography weight, size, or style (within brand family)
- Copy angle rewording (same message, different phrasing)
- Image cropping, zoom level, or camera angle
- Mood shift (bright → moody, clean → textured)
- Supporting visual elements
- Decorative elements (badges, stickers, annotations)

**What stays locked:**
- Hero element (or close variant — same product, different angle is fine)
- Core message and value proposition
- CTA intent (the action you want; button style may change)
- Brand identity (logo, core colors)
- Offer details (price, discount, guarantee)

**When to use:**
- Current creative has been running 2–4 weeks and performance is plateauing
- You want to test which supporting elements actually drive conversions
- Scaling to new audience segments that might respond to different framing
- Testing layout hypotheses (does left-aligned hero outperform centered?)

**Example prompts for moderate:**
- "Keep the product shot and headline. Change the background from a studio white to an outdoor lifestyle scene. Shift the layout so the product is on the left with text on the right."
- "Same product, same offer. Reframe the mood from bright and energetic to warm and premium. Adjust the color palette accordingly."
- "Rephrase the headline from 'Save 40% Today' to 'Your Best Deal This Month'. Keep the product shot and CTA placement. Change the background color to navy."

---

### Dramatic — New Concept, Same Core

**Philosophy:** If the original ad is a song, this is a cover in a completely different genre. Same lyrics (offer), completely different sound (creative).

**What changes:**
- Everything visual — layout, composition, art direction
- Color palette (may depart from brand palette if brand allows)
- Visual style (photo → illustration → 3D → flat design)
- Copy angle (completely new hook, same offer)
- Mood and tone
- Background, scene, environment
- Typography choices
- Supporting elements and decorative treatment
- Aspect ratio / format considerations

**What stays locked:**
- The product or service being advertised
- The core offer (price, discount, guarantee, benefit)
- Brand identity markers (logo, name — but placement may change)
- CTA purpose (the desired action)

**When to use:**
- You've exhausted moderate variations and need fundamentally new angles
- Testing whether the winning offer works with a completely different visual approach
- Expanding to a new platform where the original creative style doesn't fit
- The original ad worked because of the offer, not the creative, and you want to find the *creative* that makes it scale further

**Example prompts for dramatic:**
- "Create a completely new ad for [product] featuring the same 40% off offer. Use an illustration style instead of photography. Bold, maximalist layout with large typography."
- "Redesign this ad from scratch as a lifestyle scene — show the product being used in a home environment. Warm, aspirational mood. The only elements from the original should be the logo and the discount amount."
- "Create a minimal, text-heavy version of this ad. Black background, white sans-serif type, small product image in the corner. Same offer, completely different energy."

---

## Variation Combinations

For maximum testing coverage, combine divergence levels:

**The Standard Batch (recommended starting point):**
- 2 subtle variants (surface refresh)
- 2 moderate variants (structural remix)
- 1 dramatic variant (new concept)

**The Conservative Batch (high-performing ad, low risk tolerance):**
- 4 subtle variants
- 1 moderate variant

**The Exploration Batch (testing new angles):**
- 1 subtle variant (control-adjacent)
- 2 moderate variants
- 2 dramatic variants

---

## Platform-Specific Considerations

**Facebook/Instagram:**
- Text overlay should cover <20% of image area (guideline, not hard rule, but affects delivery)
- Feed ads: square (1:1) performs most consistently
- Stories: 9:16, text in top 1/3 and bottom 1/3, keep key elements in center safe zone
- Reels: similar to stories but punchier, bolder

**Google Display:**
- Landscape (1200x628) is the workhorse format
- Text must be legible at small sizes — banner ads render small
- Simpler compositions outperform busy ones
- Strong contrast between CTA button and background is critical

**TikTok:**
- 9:16 is mandatory
- UGC aesthetic outperforms polished advertising
- Text should feel native — handwritten or casual fonts
- Bold, high-contrast colors for thumb-stopping

**LinkedIn:**
- Professional, clean aesthetic
- Data/statistics in visuals perform well
- Blue/navy backgrounds align with platform feel
- 1200x627 landscape or 1080x1080 square

**Pinterest:**
- 2:3 vertical (1000x1500) maximizes real estate
- Aspirational lifestyle imagery
- Text overlays should be bold and legible
- Warm, inviting color palettes

---

## Performance Testing Mindset

When generating variants, think like a media buyer:

1. **Each variant should test ONE hypothesis.** "What if the background was warmer?" is a testable hypothesis. "What if everything was different?" is not.

2. **Name your hypothesis in the strategy field.** This makes performance analysis meaningful later. "I changed the background" is useless. "Testing warm gradient vs cool flat background — hypothesis: warm converts better for female 25–34 segment" is gold.

3. **Keep a control.** Always include the original (or a subtle variant that's essentially identical) as a baseline.

4. **Let the platforms optimize.** Upload all variants to the same ad set and let the algorithm distribute impressions. Don't pre-judge.

5. **Give it time.** Each variant needs 500+ impressions before you draw conclusions. Minimum 3–5 days of data.
